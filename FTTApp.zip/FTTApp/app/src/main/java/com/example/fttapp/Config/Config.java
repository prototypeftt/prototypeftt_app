package com.example.fttapp.Config;

public class Config {
    public static final String PAYPAL_CLIENT_ID = "AdgJuXaHjnn7RNxe6NVZ-eAwENpmPKQCCaP-j8Cynm8BT0TMOVN-xAi2S-9zXxhwQCwCxN5MY3laupRs";
}
