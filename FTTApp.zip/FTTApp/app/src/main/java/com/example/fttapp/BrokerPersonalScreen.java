package com.example.fttapp;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class BrokerPersonalScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.broker_personal_screen);
    }
}