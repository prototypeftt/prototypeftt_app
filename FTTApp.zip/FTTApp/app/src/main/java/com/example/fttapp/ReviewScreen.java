package com.example.fttapp;


import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class ReviewScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.review_screen);
    }

}