package com.example.fttapp;

public class Broker {
    private String name;

    public Broker() {
    }

    public Broker(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
